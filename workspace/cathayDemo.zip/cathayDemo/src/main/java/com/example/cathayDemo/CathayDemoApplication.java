package com.example.cathayDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CathayDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CathayDemoApplication.class, args);
	}

}
